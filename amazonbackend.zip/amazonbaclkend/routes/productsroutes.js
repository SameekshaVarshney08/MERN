const express= require('express');
const productscontroller= require('../controllers/productscontroller.js');
const productRouter=express.Router();
productRouter.route('/')
.get(productscontroller.getAllproducts)
.post(productscontroller.addProduct)
productRouter.route('/:id')
.put(productscontroller.replaceProduct)
productRouter.route('/:id')
.delete(productscontroller.deleteProduct);
// productRouter.route('/:id')
// .patch(productscontroller.findbyProductProduct);
module.exports=productRouter;