const mongoose= require('mongoose');
// const productModel= require('../models/productsmodel.js');
const productSchema=mongoose.Schema({
    title:{
      type:String,
      unique:true,
      required:true,
    },
    price:{
      type:Number,
      // unique:true,
      required:true,
    },
    description:String,
    images:[String],
    createdAt:{
      type:Date,
      default:new Date(),
    },
    updatedAt:{
      type:Date,
      default:new Date(),
    }
})

//  const productModel=moongose.model('products', productSchema);
//  const testproduct=new productModel({
//     title:'watch',
//     price:2000,

//  });
//  testproduct.save().then((res)=>{
//     console.log(res);

//  })
 const productmodel=mongoose.model('products', productSchema);
 module.exports=productmodel;

 
