const express = require('express');
const productsRouter=require('./routes/productsroutes.js')
// const productscontroller= require('../controllers/productscontroller.js');
const app=express();
const test=require('./models/productsmodel.js');
const mongoose=require('mongoose');
app.use(express.json());
app.use('/api/products',productsRouter);
const url='mongodb+srv://$_USERNAME_$:$_PASSWORD_$@cluster0.zti6gp3.mongodb.net/$_DBNAME_$?retryWrites=true&w=majority&appName=Cluster0'
const databaseuser='SAMEEKSHA';
const databasepassword='VARSHNEY08';
const databasename='amazonbackend';  
let dblink=url.replace("$_USERNAME_$",databaseuser);
dblink=dblink.replace("$_PASSWORD_$",databasepassword);
dblink=dblink.replace("$_DBNAME_$",databasename);
mongoose.connect(dblink)
.then(()=>console.log('...database connected....'));
app.listen(1400,
()=>console.log('...app started... ')
);