// console.log('hello');
const fs= require('fs');
const http= require('http');
const url= require('url');
const data= fs.readFileSync("./dummy.json", "utf8");
const dataObject= JSON.parse(data).carts;
// console.log(dataObject);
const htmlTemplate=`
<!DOCTYPE HTML>
<HTML lang="en-US">
    <head>
    <style>
        .products-card{
            max-width:500px;
            margin:20px auto;
            border: 8px double black;
            border-radius:50px;
            padding:15px;
            background-color:lightgreen;
            font-size:18px;
            text-align:center;
            font-weight:600;
            color:black; 
            // display:grid;
            grid-template-columns:50px 50px 50px 50px;
        }
         img{
         display:block;
         min.height:150px;
         min.width:150px;
         border-radius:100px;
         border:5px solid red;
        } 
        img:hover{
            scale:1;
        }
        p{
            font-size:20px;
            font-weight:600;
        }
        h2{
            font-size:25px;
            // color:blue;
            font-weight:1000;
            text-decoration:underline;
        }
       
    </style>
    </head>
    <body>
        CARTS-TEMPLATE
    </body>
</html>`
const cardTemplate = `
    <div class='products-card'>
    <h2>TITLE</h2>
    <img src="images">
    <p>ID=id</p>
    <p>Price=price</p>
    <p>Quantity=quantity</p>
    <p>Total=total</p>
    <a href="/product?id=link">more info</a>
    </div>
`;
 let result=[];
    for(let i=0; i<dataObject.length;i++){
        // let temp=cardTemplate;
        // temp=temp.replace('TITLE',dataObject[i].products[1]);
        // console.log(temp);
        // res.push(cardTemplate);
      //  result.push(temp);
       // const dataObject2= JSON.parse(data).carts;
       const products=dataObject[i].products;
        for(let j=0; j<products.length;j++){
            let temp1=cardTemplate;
            temp1=temp1.replace('id',products[j].id);  
            temp1=temp1.replace('TITLE',products[j].title);  
            temp1=temp1.replace('images',products[j].thumbnail);
            temp1=temp1.replace('price',products[j].price);
            temp1=temp1.replace('quantity',products[j].quantity);
            temp1=temp1.replace('total',products[j].total);
        // console.log(temp);
        // res.push(cardTemplate);
           result.push(temp1);
        }
    }
    result=result.join(' ');
    const page=htmlTemplate.replace('CARTS-TEMPLATE',result);

    // console.log(res);
 
const server=http.createServer((req,res)=>{
    // const path=url.parse(req.url);
    // const pathname=path.pathname;
    const url=require('url');
    // const {pathname}=url.parse(req.url);
    const path=url.parse(req.url,true);
    const pathname=path.pathname;
    const q=path.query;
    console.log('\n',pathname,'\n');
    // const q=pathname.query;
    if(pathname=='/home'){
        res.end(page);
    }
    else if(pathname=='/products'){
        const id=q.id;
        const temp=[];
        Object.foreach(({products})=>{
            products.foreach((item)=>{
            temp.push(item);
            })
        })
        // const item=dataObject[id];
        const searchItem=temp.filter(({id})=>{
            return (id==qid);
        });
        res.end('productpage'+searchItem[0].title);
    }
        //  <div>
        //  <h4>${item.title}</h4>
        //  </div>
        // `);
    else{
        res.end('404...not found');
    }
//    res.end(result);
});
    server.listen(1500,()=>{
    console.log("....server started...");
});


