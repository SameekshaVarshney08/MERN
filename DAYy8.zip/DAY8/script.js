const express= require('express')
const app= express()
app.get('/home',(req,res)=>{
res.send('<h1>sameeksha</h1>');
});
app.post('/home',(req,res)=>{
res.send('<h1>prathamkumari</h1>');
    });
app.patch('/home',(req,res)=>{
res.send('<h1>jatinkumari</h1>');
        });
app.delete('/home',(req,res)=>{
res.send('<h1>yashi</h1>');
            });
app.listen(1400)
//postman installation